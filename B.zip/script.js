var cell_class= 
document.getElementsByClassName("cell");